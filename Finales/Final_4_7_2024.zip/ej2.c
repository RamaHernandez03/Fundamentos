#include <stdio.h>
#include <stdbool.h>

#define MAX_HABITACIONES 11
const int FIL_ENTRADA = 0;
const int COL_ENTRADA = 0;
const int FIL_SALIDA = 10;
const int COL_SALIDA = 8;

typedef struct habitacion {
    int fil_sig_habitacion;
    int col_sig_habitacion;
    bool hay_muebles;
} habitacion_t;

// Dada una matriz de habitaciones que representa el cuartel de Síndrome, crear una función
// que cuente la cantidad de habitaciones que recorre Mr. Increíble hasta que logra salir del cuartel.
// Asumir que siempre se va a poder encontrar la salida.

/*  Pre condiciones: El conjunto de los campos fil_sig_habitacion y col_sig_habitacion de todas las
       habitacion_t deben contener una coordenada dentro del rango de la matriz.
    Post condiciones: Devuelve la cantidad de habitaciones que se recorren entre
        {FIL_ENTRADA, COL_ENTRADA} y {FIL_SALIDA, COL_SALIDA}.
*/
int habitaciones_recorridas(habitacion_t habitaciones[MAX_HABITACIONES][MAX_HABITACIONES]) {
    bool salio = false;
    int fil_actual = FIL_ENTRADA;
    int col_actual = COL_ENTRADA;
    int contador_habitaciones = 0;

    while(!salio){
        if(fil_actual == FIL_SALIDA && col_actual == COL_SALIDA)
            salio = true;
        else {
            habitacion_t actual = habitaciones[fil_actual][col_actual];
            fil_actual = actual.fil_sig_habitacion;
            col_actual = actual.col_sig_habitacion;
        }

        contador_habitaciones++;
    }

    return contador_habitaciones;
}


// el main no hace falta hacerlo en el exámen, sólo la función como pide el enunciado
int main() {
    habitacion_t habitaciones[MAX_HABITACIONES][MAX_HABITACIONES] = {
        {{1, 1, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {2, 2, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {3, 2, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {5, 2, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {6, 3, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {8, 5, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {9, 6, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {10, 8, false}, {0, 0, false}, {0, 0, false}},
        {{0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}, {0, 0, false}}
    }; // pasa por 9 habitaciones

    printf("MR INCREIBLE pasa por %i habitaciones\n", habitaciones_recorridas(habitaciones));

    return 0;
}

/*
Parte teórica:
1. La diferencia entre un for y un while es que el for se utiliza cuando se conoce la cantidad de iteraciones que se van a realizar, mientras que el while se utiliza cuando no se conoce la cantidad de iteraciones que se van a realizar pero si se conoce una condición para evaluar si se debe seguir iterando o no.
Ambas son estructuras de control de flujo que permiten repetir un bloque de código. Un caso donde conviene usar un for es, por ejemplo, cuando se quiere recorrer un vector de principio a fin, ya que se conoce la cantidad de elementos. Por otro lado, un caso donde conviene usar un while es cuando se quiere buscar un elemento en un vector, ya que no se sabe en qué posición se encuentra el elemento.

2. La afirmación es falsa. El máximo de un vector es la cantidad de elementos que puede llegar a tener un vector, se usa para calcular su tamaño en memoria. El tope de un vector es la cantidad de elementos que tiene actualmente el vector. Por ejemplo, si se tiene un vector de máximo 10, el tope puede ser 0 si está vacío, 5 si tiene 5 elementos, o 10 si está lleno.
*/
