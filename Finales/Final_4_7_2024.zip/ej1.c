#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_COLOR 20
#define MAX_TRAJES 20
const int NO_ENCONTRADO = -1;
#define COLOR_BUSCADO "Rojo"

typedef struct supertraje {
    int antiguedad;
    char color[MAX_COLOR];
    bool es_ganador;
} supertraje_t;

// Dado un vector de supertrajes que contiene todos los supertrajes de Mr. Increíble y su tope,
// crear una función recursiva que devuelva la posición del traje más nuevo, que sea de color rojo.

/*  Pre condiciones: tope_trajes debe contener un valor mayor o igual a 0 y menor a MAX_TRAJES, actual debe
        contener un valor mayor o igual a 0 y encontrado debe contener un valor mayor o igual a -1 y
        menor a MAX_TRAJES.
    Post condiciones: devuelve el indice del traje buscado o -1 si no es encontrado.
*/
int traje_buscado_rec(supertraje_t trajes[MAX_TRAJES], int tope_trajes, int actual, int encontrado) {
    if(actual >= tope_trajes)
        return encontrado;

    if(strcmp(trajes[actual].color, COLOR_BUSCADO) == 0 && (encontrado == NO_ENCONTRADO || trajes[actual].antiguedad < trajes[encontrado].antiguedad))
        encontrado = actual;

    return traje_buscado_rec(trajes, tope_trajes, actual + 1, encontrado);
}

/*  Pre condiciones: tope_trajes debe contener un valor mayor o igual a 0 y menor a MAX_TRAJES
    Post condiciones: devuelve el indice del traje buscado o -1 si no es encontrado
*/
int traje_buscado(supertraje_t trajes[MAX_TRAJES], int tope_trajes) {
    return traje_buscado_rec(trajes, tope_trajes, 0, NO_ENCONTRADO);
}


// el main no hace falta hacerlo en el exámen, sólo la función como pide el enunciado
int main() {
    supertraje_t trajes[MAX_TRAJES] = {
        {5, "Rojo", true},
        {3, "Azul", true},
        {1, "Verde", true},
        {2, "Rojo", true},
        {5, "Gris", true},
        {0, "Naranja", true}
    };

    int traje = traje_buscado(trajes, 6);
    if(traje != NO_ENCONTRADO)
        printf("El traje mas nuevo y rojo es el del indice %i\n", traje);
    else
        printf("Traje no encontrado :(\n");
    return 0;
}

/*
Parte teórica:
1. Una función recursiva debe tener:
- Una condición de corte: es la que determina cuando la función debe dejar de llamarse a si misma.
- Una sección de procesamiento: es la que se encarga de realizar el trabajo de la función.
- Una llamada recursiva: es la que se encarga de llamar a la función a si misma.

2. El campo `color` es un string. La particularidad del string es que es un vector de caracteres terminado en '\0'. Se usa este caracter nulo para marcar el final del vector en vez de usar un tope.
*/
