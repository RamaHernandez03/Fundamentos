import csv

NO_ENCONTRADO = -1

def cantidad_producto(producto_buscado, productos_comprados):
    cantidad = NO_ENCONTRADO

    for producto in productos_comprados:
        if producto[0] == producto_buscado:
            cantidad = producto[1]

    return cantidad


with open('faltantes.csv', 'w') as archivo_faltantes:
    writer = csv.writer(archivo_faltantes, delimiter=';')
    faltan = []

    with open('ticket.csv', 'r') as archivo_ticket:
        reader = csv.reader(archivo_ticket, delimiter=';')
        comprados = []
        for producto in reader:
            comprados.append(producto)

        with open('lista_compras.csv', 'r') as archivo_lista_compras:
            reader = csv.reader(archivo_lista_compras, delimiter=';')
            for producto in reader:
                cant_producto_buscado = int(cantidad_producto(producto[0], comprados))

                if cant_producto_buscado == NO_ENCONTRADO:
                    writer.writerow(producto)

                elif cant_producto_buscado < int(producto[1]):
                    writer.writerow([producto[0], int(producto[1]) - cant_producto_buscado])
