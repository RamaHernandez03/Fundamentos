import csv
import os

# Defino algunas constantes que nos van a servir.
NOMBRE_ARCHIVO_STOCK = 'stock.csv'
NOMBRE_ARCHIVO_PEDIDO = 'pedido.csv'
DIAS_PARA_CADUCAR = 0
NOMBRE_STOCK = 1
CANTIDAD_STOCK = 2
NOMBRE_PEDIDO = 0
CANTIDAD_PEDIDO = 1
MINIMOS_DIAS_CADUCAR = 2
STOCK_COMPLETO = 100

def main():
    #Abro los dos archivos que voy a usar para el ejercicio. También se puede hacer con `with`.
    try:
        archivo_stock=open(NOMBRE_ARCHIVO_STOCK, 'r')
    except:
        print("No se pudo abrir el archivo de stock")
        return 

    try:
        archivo_pedido = open(NOMBRE_ARCHIVO_PEDIDO, 'w')
    except:
        return 


    reader = csv.reader(archivo_stock, delimiter = ';')
    writer = csv.writer(archivo_pedido, delimiter = ';')

    #Leo el archivo de stock y voy agregando cosas a mi archivo de pedido.
    for linea in reader:
        if int(linea[DIAS_PARA_CADUCAR]) <= MINIMOS_DIAS_CADUCAR:
            writer.writerow(linea[NOMBRE_STOCK], STOCK_COMPLETO)
        #Este if se encarga de revisar cuando el dia de caducar sea menor o igual a 2.

        elif int(linea[CANTIDAD_STOCK]) < STOCK_COMPLETO:
            cantidad_a_pedir = (STOCK_COMPLETO - int(linea[CANTIDAD_STOCK]))
            writer.writerow(linea[NOMBRE_STOCK], cantidad_a_pedir)
        #Este if se encarga de revisar cuando no tiene completo el stock.
            
    archivo_stock.close()
    archivo_pedido.close()

main()

# TEORICA
# El procedimiento es similar al de las operaciones con vectores. Como sabemos que ambos están ordenados podemos ir recorriendolos de manera ordenada también, esto sería avanzando siempre el que tiene menor nombre de ambos. En cada paso podemos tener 3 casos:
#   - Cuando ambos nombres coincidan sabemos que es un caso donde hay que actualizar el stock. 
#   - Si el nombre del pedido es menor, esto significa que vino un nuevo producto y hay que pasarlo al archivo de stock. 
#   - Si el nombre del stock es menor, esto significa que este producto está en el stock pero no vino en el pedido, no hay nada que actualizar.
# Si cuando se termina el archivo de stock, todavía quedan elementos en el de pedidos tengo que pasar todos esos al nuevo archivo de stock porque sabemos que son todos productos que no estaban en el stock pero vinieron en el pedido.