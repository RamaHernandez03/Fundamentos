#include <string.h>
#include <stdbool.h>

//DEFINIMOS LAS CONSTANTES NECESARIAS.
#define ROJO "Rojo" 
#define AZUL "Azul"

/* 
    Lógica para revisar los campos de los structs:
    - Para saber si una araña es venenosa: para acceder a una araña tenemos q hacer `arañas[<posicion que necesitemos>]`, y desde esa araña tenemos que entrar al campo es venenosa, como la araña no es un puntero, utilizamos el punto por ende `arañas[posicion_actual].es_venenosa` es la forma de acceder al campo para saber si es venenosa. 
    - Para acceder a la cantidad de colores es igual.
    - Para acceder a un nombre color dentro de una araña:
        - Primero necesitamos acceder a una araña, supongamos `arañas[5]`
        - Luego necesitamos acceder al campo de colores que es un vector, hacemos `arañas[5].colores` (este es el vector de colores de una araña)
        - Ahora hacemos `arañas[5].colores[0]` esto es un struct color_t, no es un string que podamos comparar
        - Por ende nos falta acceder al campo nombre de ese struct que asumimos es un string con el nombre del color `arañas[5].colores[0].nombre`. Esto nos daría el nombre del primer color de la araña, nosotros tenemos que recorrer todos para ver si es Roja y Azul.
*/

/* forma de devolver las cosas, esta forma de devolver el numero utilizando la funcion dentro del return imaginensela como que evaluas la araña y te guardas si sirve o no (0 o 1), y luego pedis la proxima (se suma el valor de esa araña) y pedis otra, asi hasta llegar al caso base, donde se devuelve 0 porque no evaluamos una araña, entonces se empieeza a evaluar desde abajo, o desde la ultima araña en este caso, y se va acumulando a medida que se deja de esperar el resultado siguiente. */


int cant_arañas_recursiva(araña_t arañas[MAX_ARAÑAS], int tope_arañas, int posicion_actual){
    //Empezamos definiendo el caso base, en caso de que la posicion actual sea igual al tope de las arañas significa que ya evaluamos todas las arañas.
    if (posicion_actual == tope_arañas){
        return 0;
    }   

    // Si la araña es venenosa no nos sirve en este caso y ya la descartamos, asi que entonces devolvemos 0 + la suma del resto de las arañas cuando las evaluemos, volvemos a llamar a la funcion solo que ahora cambiamos la posicion a la proxima en el vector.
    if (arañas[posicion_actual].es_venenosa)
    {
        return 0 + cant_arañas_recursiva(arañas, tope_arañas, posicion_actual++);
    }

    bool encontre_color_rojo = false;
    bool encontre_color_azul = false;

    while(i < arañas[posicion_actual].cant_colores && !(encontre_color_azul && encontre_color_rojo)){ 
        // La parte de `&& !(encontre_color_azul && encontre_color_rojo)` hace que si encontre ambos color deje de iterar porque ya encontre lo que necesito (si no esta el algoritmo funciona igual solo que asi nos ahorramos iterar un par de veces de mas)
        if (strcmp(arañas[posicion_actual].colores[i].nombre, ROJO) == 0){
            encontre_color_rojo = true; 
        } else if (strcmp(arañas[posicion_actual].colores[i].nombre, AZUL) == 0){
            encontre_color_azul = true; 
        }
    }
    
    if (encontre_color_rojo && encontre_color_azul){
        return 1 + cant_arañas_recursiva(arañas, tope_arañas, posicion_actual++); 
        // hago lo mismo que arriba solo que ahora si cuenta en nuestra busqueda por lo que devolvemos 1 + el resto de arañas evaluadas respectivamente
    } else {
        return 0 + cant_arañas_recursiva(arañas, tope_arañas, posicion_actual++); 
        // esto significa que no encontre el color, por ende no nos sirve para el contador y devolvemos 0.
    }

}

int cant_arañas(araña_t arañas[MAX_ARAÑAS], int tope_arañas){
    cant_arañas_recursiva(arañas, tope_arañas, 0);
}

// TEORICA
// 1- Esto depende de la naturaleza del problema que querramos resolver, casi siempre se puede hacer de ambas formas aunque sea mucho más complejo o más facil dependiendo de la naturaleza del problema. Para problemas que pueden ser resueltos aplicando la misma solución a partes más pequeñas, como búsqueda binaria, conviene usar recursividad. Si el problema no cumple con esta condición es probable que una implementación iterativa sea más facil y legible.

//2- El campo de colores es un vector de elementos `color_t`.
