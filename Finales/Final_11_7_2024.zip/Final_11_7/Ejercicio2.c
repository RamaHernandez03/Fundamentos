typedef struct habitacion{
    int numero;
    char ocupantes[MAX_OCUPANTES]; // inicial del nombre
    int cantidad_ocupantes;
} habitacion_t;

//CONSTANTES
#define MAX_OCUPANTES 100
#define MAX_HABITACIONES 100 
#define MAX_PISOS 100 

const char ANNIE = 'A';
const char HALLIE = 'H';
const char NICHOLAS = 'N';
const char ELIZABETH = 'E';
const char MEREDITH = 'M';

// Definir un struct no es obligatorio, solo va a hacer que nuestro código sea más legible. En vez de tener una variable para la fila y otra la cada columna puedo tener una coordenada_t.
typedef coordenada{
    int fila;
    int columna;
} coordenada_t;

// Este ejercicio va a ser mucho más facil si identificamos la parte dificil: Encontrar donde está cada uno de los personajes en el hotel. Si modularizamos esta parte dificil en una función que busque a UNA sola persona entonces el resto va a salir mucho más facil.

// Pre: La persona recibida se debe encontrar en el hotel
// Post: Devuelve la coordenada del hotel en la que se encuentra la persona
coordenada_t encontrar_persona(habitacion_t hotel[MAX_PISOS][MAX_HABITACIONES], char persona){
    coordenada_t coord_buscado = {0;0};

    // Primero recorro cada habitación del hotel. Como es una matriz uso dos for.
    for(int i = 0; j < MAX_PISOS; i++){
        for(int j = 0; j < MAX_HABITACIONES; j++){

            // Ahora que estoy parado en la habitacion `hotel[i][j]` tengo que recorrer a todos los ocupantes para ver si alguno es el que busco. Como `ocupantes` es un vector de iniciales uso un for para recorrer cada inicial y ver si alguna coincide.
            for(int k = 0; j < hotel[i][j].cantidad_ocupantes; j++){
                if(hotel[i][j].ocupantes[k] == persona){
                    coord_buscado.fila = i;
                    coord_buscado.columna = j;
                } 
            }
        }
    }
    
    return coord_buscado;
}

//Pre: La matriz hotel debe contener a todos los personajes del enunciado
//Post: Devuelve true si la broma es exitosa y false en caso contrario
bool es_broma_exitosa(habitacion_t hotel[MAX_PISOS][MAX_HABITACIONES]){
    coordenada_t pos_hallie = encontrar_persona(hotel, HALLIE);
    coordenada_t pos_annie = encontrar_persona(hotel, ANNIE);
    coordenada_t pos_nicholas = encontrar_persona(hotel, NICHOLAS);
    coordenada_t pos_elisabeth = encontrar_persona(hotel, ELIZABETH);
    coordenada_t pos_meredith = encontrar_persona(hotel, MEREDITH);


    //Ahora sabemos donde está cada persona nos queda la parte facil. Ver si se cumplen todas las condiciones.

    if (pos_hallie.fila != pos_annie.fila){
        // Si las chicas no están en el mimso piso entonces la broma es fallida
        return false;
    }
    
    if ((pos_nicholas.fila == pos_annie.fila + 1 && pos_elisabeth.fila == pos_annie.fila - 1) 
        || (pos_nicholas.fila == pos_annie.fila - 1 && pos_elisabeth.fila == pos_annie.fila + 1)){
        // Si los padres las tienen rodeadas a las chicas entonces la broma es fallida. Esto puede ocurrir estando Nicholas abajo y Elisabeth arriba o al revés, por eso hay que chequear las dos
        return false;
    }

    if (pos_nicholas.fila == pos_meredith.fila && pos_nicholas.columna == pos_meredith.columna){
        // Si Nicholas y Meredith se encuentran en la misma posición entonces la broma es fallida
        return false;
    }

    // Si ninguna de las condiciones anteriores se cumple entonces la broma es exitosa
    return true;
}

// TEORICA
// 1- Las pre condiciones se refieren a lo que es necesario que cumplan los parmetros recibidos para asegurar el correcto funcionamiento de nuestro codigo. Por ejemplo en el punto anterior una pre condicion valida seria que la matriz contenga a todos los integrantes, ya que si esto no se cumple nuestro programa no funcionaría.
// Las post condiciones nos dicen que cosas se van a cumplir una vez ejecutada la función (y asumiendo que se cumplen las pre condiciones), en resumen, nos dice QUE hace la funcion. En el punto anterior una buen post condicion seria que la funcion devuelve true si la broma es exitosa y false si no lo es.


// 2- Esto es verdadero, el tope nos dice cuantos elementos contiene un vector. Como los indices del vector empiezan en 0, si el vector contiene un solo elemento (tope=1) la posición `vector[tope]` sería basura. Lo mismo pasaría para cualquier otro valor de tope. 


